<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.2/dist/leaflet.css"
     integrity="sha256-sA+zWATbFveLLNqWO2gtiw3HL/lh1giY/Inf1BJ0z14="
     crossorigin=""/>
     <script src="https://unpkg.com/leaflet@1.9.2/dist/leaflet.js"
     integrity="sha256-o9N1jGDZrf5tS+Ft4gbIK7mYMipq9lqpVJ91xHSyKhg="
     crossorigin=""></script>
    <link rel="stylesheet" type="text/css" href="stylemapas.css" />
    
    <title>Search Care</title>
</head>
<body>


    
    <div class="caixa">
<div class ="cadastro">
<a href="indexcadastro.php"><button class="butaocadastro">Cadastro</button></a>
</div>
<div class ="login">
<a href="indexlogin.php"><button class="butaologin">Login</button></a>
</div>
<div class = "header"><img class="logo" src="./img/veio.png" alt="">
</div>
</div>

<div class="search-box">
        <input type="text" class="search-text" placeholder="Pesquisar...">
        <a class ="search-btn">
            <img class="lupa" src="./img/lupa.png" alt="" width="25px" height="25px">
        </a>
    </div>
    <div class = "localizacao">
    <h1>Sua localizaçao é:</h1>
    </div>
<h2></h2>


    
    <style>
        #map { height: 1000px; 
            width: 90%;
            margin-left: 5%;
        }
    </style>
    
    <div id="map"></div>
    

    <style>

    @media screen and (max-width: 780px){
        section, aside{
            width:100%;
            padding:0;
        }
        
    }
       </style>

    <center><script src ="script.js"></script></center>
    </body>
    </html>