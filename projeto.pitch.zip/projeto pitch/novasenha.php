

<!DOCTYPE html>
<head>
  <meta charset="UTF-8" />
  <title>Nova senha</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <link rel="stylesheet" type="text/css" href="stylesenha.css" />
</head>
<body>
  <div class="container" >
    <a class="links" id="paracadastro"></a>
     
    <div class="content">      
      
      <div id="cadastro">
        <form method="post" action="index.php"> 
          <h1>Nova senha</h1> 
          <p> 
            <label for="nome_login">Seu e-mail</label>
            <input id="nome_login" name="nome_login" required="required" type="text" placeholder="ex. searchcare@gmail.com"/>
          </p>
           
          <p> 
            <label for="email_login">Sua nova senha</label>
            <input id="email_login" name="email_login" required="required" type="password" placeholder="ex. 1234" /> 
          </p>

          <p> 
          <input type="submit" value="Logar" />
          </p>

          <?php
    
 