let h2 = document.querySelector('h2');

function succes(pos){
    console.log(pos.coords.latitude, pos.coords.longitude);
    
    var map = L.map('map').setView([pos.coords.latitude, pos.coords.longitude], 13);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    L.marker([pos.coords.latitude, pos.coords.longitude]).addTo(map)
    .bindPopup('Você esta aqui.')
    .openPopup();

    L.marker([-19.919435120612587, -43.979927375872364], {icon: greenIcon}).addTo(map).bindPopup("Lar Dona Paula da SSVP R. Henrique Gorceix, 315 - Padre Eustáquio, Belo Horizonte - MG, 30720-416");
    L.marker([-19.91541894447307, -43.91234326459535], {icon: greenIcon}).addTo(map).bindPopup("Lar de Idosas Santa Tereza e Santa TerezinhaR. Divinópolis, 225 - Santa Tereza, Belo Horizonte - MG, 31010-370");
    L.marker([-19.9219690801917, -43.92584150017776], {icon: redIcon}).addTo(map).bindPopup("Instituto Geriátrico Afonso Pena - IGAP R. Domingos Vieira, 586 - Santa Efigênia, Belo Horizonte - MG, 30150-240");
    L.marker([-19.92855094423503, -43.99894235583886], {icon: orangeIcon}).addTo(map).bindPopup("Lar dos Idosos Santa Rita de Cássia R. Barão de Guaxupé, 362 - João Pinheiro, Belo Horizonte - MG, 30530-160");
    L.marker([-19.93928209297567,  -43.987022449254596], {icon: pretoIcon}).addTo(map).bindPopup("Saber Viver R. da Igualdade, 62 - Nova Gameleira, Belo Horizonte - MG, 30510-450");
    L.marker([-19.90867731404814,  -43.95961157134257], {icon: brancoIcon}).addTo(map).bindPopup("Vida Digna - Residência para Idosos R. Sabinópolis, 356 - Carlos Prates, Belo Horizonte - MG, 30710-340");
    L.marker([-19.934696458962897,  -44.01830927134257], {icon: blueIcon}).addTo(map).bindPopup("Recanto Conviver Rua Jose Motta Costa, 870 - Camargos, Belo Horizonte - MG, 30525-390");
    L.marker([-19.987063029069628,  -43.95976960017776], {icon: purpleIcon}).addTo(map).bindPopup("Lar dos Idosos São José R. São José, 200 - Olhos D'Água, Belo Horizonte - MG, 30514-280");
    L.marker([-19.863090792885377,  -43.949150806924976], {icon: pinkIcon}).addTo(map).bindPopup("Novo Lar Maturidade com Auxílio - Casa de Repouso R. Dom Rodrigo, 316 - Santa Rosa, Belo Horizonte - MG, 31255-720");
    L.marker([-19.8528488004817,  -43.993092264595354], {icon: brownIcon}).addTo(map).bindPopup("Pampulha Village Casa de Repouso para Idosos BH Av. Otacílio Negrão de Lima, 6018 - Bandeirantes (Pampulha), Belo Horizonte - MG, 31340-595");
    
    
}



function error(err){
    console.log(err);
}


var watchID = navigator.geolocation.watchPosition(succes, error , {
    enableHighAccuracy: true,
    timeout: 5000
});
//navigator.geolocation.clearWatch(watchID) ;



var greenIcon = L.icon({
    iconUrl: './img/asilo.png',
    

    iconSize:     [24, 24], // size of the icon
    shadowSize:   [50, 50], // size of the shadow
    iconAnchor:   [20, 20], // point of the icon which will correspond to marker's location
    shadowAnchor: [4, 4],  // the same for the shadow
    popupAnchor:  [-3, -3] // point from which the popup should open relative to the iconAnchor
    
    
});

var LeafIcon = L.Icon.extend({
    options: {
        iconwUrl: './img/asilo.png',
        iconSize:     [38, 38],
        shadowSize:   [50, 64],
        iconAnchor:   [22, 22],
        shadowAnchor: [4, 62],
        popupAnchor:  [-3, -3]
    }
});

var greenIcon = new LeafIcon({iconUrl: './img/asilo.png'}),
    redIcon = new LeafIcon({iconUrl: './img/asilo.png'}),
    orangeIcon = new LeafIcon({iconUrl: './img/asilo.png'});
   pretoIcon = new LeafIcon({iconUrl: './img/asilo.png'});
   brancoIcon = new LeafIcon({iconUrl: './img/asilo.png'});
   blueIcon = new LeafIcon({iconUrl: './img/asilo.png'});
   purpleIcon = new LeafIcon({iconUrl: './img/asilo.png'});
   pinkIcon = new LeafIcon({iconUrl: './img/asilo.png'});
   brownIcon = new LeafIcon({iconUrl: './img/asilo.png'});

    L.icon = function (options) {
        return new L.Icon(options);
    };



   
  





